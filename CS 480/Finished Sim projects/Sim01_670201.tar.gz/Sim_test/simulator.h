#ifndef SIMULATOR_H
#define SIMULATOR_H

#include "configops.h"
#include "metadataops.h"

void runSim ( ConfigDataType *configPtr, OpCodeType *metaDataMstrPtr );

#endif